require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const connectDB = require('./config/db');
const User = require('./models/User');
const Restaurant = require('./models/Restaurant');
const MenuItem = require('./models/MenuItem');

const MONGO = process.env.MONGO_URI || 'mongodb://localhost:27017/foodapp';

async function seed() {
  await connectDB(MONGO);
  await User.deleteMany({});
  await Restaurant.deleteMany({});
  await MenuItem.deleteMany({});

  const password = await bcrypt.hash('password', 10);
  const customer = await User.create({ name: 'Demo Customer', email: 'customer@example.com', password, role: 'customer' });
  const partner = await User.create({ name: 'Demo Partner', email: 'partner@example.com', password, role: 'partner' });
  const rider = await User.create({ name: 'Demo Rider', email: 'rider@example.com', password, role: 'rider' });

  const r1 = await Restaurant.create({ name: 'Pasta Palace', description: 'Tasty pastas', owner: partner._id, address: '123 Main St', cuisine: 'Italian' });
  const r2 = await Restaurant.create({ name: 'Curry Corner', description: 'Spicy and savory', owner: partner._id, address: '456 Market St', cuisine: 'Indian' });

  await MenuItem.create({ restaurant: r1._id, name: 'Spaghetti Bolognese', description: 'Classic', price: 9.99 });
  await MenuItem.create({ restaurant: r1._id, name: 'Penne Alfredo', description: 'Creamy', price: 8.99 });
  await MenuItem.create({ restaurant: r2._id, name: 'Butter Chicken', description: 'Mild and creamy', price: 10.99 });
  await MenuItem.create({ restaurant: r2._id, name: 'Lamb Rogan Josh', description: 'Spicy', price: 12.5 });

  console.log('Seed complete — users: customer@example.com / partner@example.com / rider@example.com (password)');
  process.exit(0);
}

seed().catch(err => { console.error(err); process.exit(1); });
