require('dotenv').config();
const express = require('express');
const http = require('http');
const session = require('express-session');
const passport = require('passport');
const cors = require('cors');
const connectDB = require('./config/db');

const authRoutes = require('./routes/auth');
const restaurantsRoutes = require('./routes/restaurants');
const ordersRoutes = require('./routes/orders');

const app = express();
const server = http.createServer(app);
const { Server } = require('socket.io');
const io = new Server(server, { cors: { origin: process.env.CLIENT_URL || 'http://localhost:3000', methods: ['GET','POST'], credentials: true } });
app.set('io', io);

// DB
connectDB(process.env.MONGO_URI || 'mongodb://localhost:27017/foodapp');

app.use(cors({ origin: process.env.CLIENT_URL || 'http://localhost:3000', credentials: true }));
app.use(express.json());

app.use(session({ secret: process.env.SESSION_SECRET || 'devsecret', resave: false, saveUninitialized: false, cookie: { maxAge: 1000 * 60 * 60 * 24 } }));
app.use(passport.initialize());
app.use(passport.session());

// routes
app.use('/api/auth', authRoutes);
app.use('/api/restaurants', restaurantsRoutes);
app.use('/api/orders', ordersRoutes);

// stripe checkout-session stub
app.post('/api/checkout', (req, res) => {
  // In a real app, create a Stripe Checkout Session here. Return a stub for demo.
  res.json({ sessionId: 'cs_test_demo_placeholder' });
});

io.on('connection', (socket) => {
  console.log('socket connected', socket.id);
  socket.on('disconnect', () => console.log('socket disconnected', socket.id));
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => console.log(`Server running on port ${PORT}`));
