const express = require('express');
const router = express.Router();
const Order = require('../models/Order');
const MenuItem = require('../models/MenuItem');

// create order
router.post('/', async (req, res) => {
  try {
    const { restaurantId, items } = req.body; // items: [{menuItemId, qty}]
    if (!req.user) return res.status(401).json({ message: 'Login required' });
    const populated = [];
    let total = 0;
    for (const it of items) {
      const mi = await MenuItem.findById(it.menuItemId).lean();
      if (!mi) continue;
      const line = { menuItem: mi._id, name: mi.name, qty: it.qty, price: mi.price };
      total += mi.price * it.qty;
      populated.push(line);
    }
    const order = new Order({ customer: req.user.id, restaurant: restaurantId, items: populated, total });
    await order.save();

    // emit via Socket.IO if available
    if (req.app.get('io')) {
      req.app.get('io').emit('order:created', order);
    }

    res.json(order);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});

// get orders for current user (customer) or for partner's restaurants (partner) or all (admin)
router.get('/', async (req, res) => {
  if (!req.user) return res.status(401).json({ message: 'Login required' });
  const role = req.user.role;
  let orders;
  if (role === 'customer') {
    orders = await Order.find({ customer: req.user.id }).populate('restaurant').lean();
  } else if (role === 'partner') {
    // partner: orders for restaurants they own (simple)
    // For brevity, return all orders (expand later)
    orders = await Order.find().populate('restaurant').lean();
  } else {
    orders = await Order.find().populate('restaurant').lean();
  }
  res.json(orders);
});

// update status (partner / rider)
router.put('/:id/status', async (req, res) => {
  const { status, riderId } = req.body;
  if (!req.user) return res.status(401).json({ message: 'Login required' });
  const order = await Order.findById(req.params.id);
  if (!order) return res.status(404).json({ message: 'Order not found' });
  order.status = status || order.status;
  if (riderId) order.rider = riderId;
  await order.save();
  if (req.app.get('io')) req.app.get('io').emit('order:updated', order);
  res.json(order);
});

module.exports = router;
