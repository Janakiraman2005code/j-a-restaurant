const express = require('express');
const router = express.Router();
const Restaurant = require('../models/Restaurant');
const MenuItem = require('../models/MenuItem');

// list restaurants
router.get('/', async (req, res) => {
  const list = await Restaurant.find().lean();
  res.json(list);
});

// get restaurant + menu
router.get('/:id', async (req, res) => {
  const rest = await Restaurant.findById(req.params.id).lean();
  if (!rest) return res.status(404).json({ message: 'Not found' });
  const menu = await MenuItem.find({ restaurant: rest._id }).lean();
  res.json({ restaurant: rest, menu });
});

// create (partner only) - simple check
router.post('/', async (req, res) => {
  if (!req.user || req.user.role !== 'partner') return res.status(403).json({ message: 'Forbidden' });
  const r = new Restaurant({ ...req.body, owner: req.user.id });
  await r.save();
  res.json(r);
});

module.exports = router;
