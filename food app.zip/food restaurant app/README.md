# Food Restaurant App — MERN starter

Features included in this scaffold:
- Customer app (React + Vite + Tailwind)
- Partner dashboard endpoints (Express)
- Delivery/order management (Express + Mongoose)
- Session-based auth (passport + express-session)
- Real-time order events (Socket.IO)
- Stripe checkout stub
- Docker + docker-compose + seed script

Quick start (development)
1. Copy `.env.example` to `.env` and set values.
2. Run services with Docker-compose:
   - `docker-compose up --build`
3. Seed sample data (in another shell):
   - `cd server && npm install && npm run seed`

Local dev (no Docker)
- Server: `cd server && npm install && npm run dev` (port 5000)
- Client: `cd client && npm install && npm run dev` (port 3000)

Demo accounts (seed creates):
- customer@example.com / password
- partner@example.com / password
- rider@example.com / password

Next steps you can ask me to do:
- Add partner dashboard UI and routes
- Implement Stripe payments end-to-end
- Add CI/CD for deployments
- Add push/SMS notifications

