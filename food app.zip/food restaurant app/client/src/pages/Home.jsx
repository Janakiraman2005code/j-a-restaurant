import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

export default function Home(){
  const [restaurants, setRestaurants] = useState([]);
  useEffect(()=>{ axios.get('/api/restaurants').then(r=>setRestaurants(r.data)).catch(()=>{}); }, []);
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Restaurants</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {restaurants.map(r=> (
          <Link to={`/restaurant/${r._id}`} key={r._id} className="p-4 bg-white rounded shadow-sm">
            <h3 className="font-medium">{r.name}</h3>
            <p className="text-sm text-slate-500">{r.cuisine} — {r.address}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
