import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';

export default function Restaurant(){
  const { id } = useParams();
  const [rest, setRest] = useState(null);
  const [menu, setMenu] = useState([]);

  useEffect(()=>{ axios.get(`/api/restaurants/${id}`).then(r=>{ setRest(r.data.restaurant); setMenu(r.data.menu); }).catch(()=>{}); }, [id]);

  const addToCart = (item) => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    cart.push({ id: item._id, name: item.name, price: item.price, qty: 1, restaurantId: id });
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Added to cart');
  };

  if (!rest) return <div>Loading...</div>;
  return (
    <div>
      <h1 className="text-2xl font-semibold">{rest.name}</h1>
      <p className="text-sm text-slate-500">{rest.description}</p>
      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        {menu.map(m=> (
          <div key={m._id} className="p-3 bg-white rounded shadow-sm flex justify-between items-center">
            <div>
              <div className="font-medium">{m.name}</div>
              <div className="text-sm text-slate-500">{m.description}</div>
            </div>
            <div className="text-right">
              <div className="font-semibold">${m.price.toFixed(2)}</div>
              <button onClick={()=>addToCart(m)} className="mt-2 px-3 py-1 bg-indigo-600 text-white rounded text-sm">Add</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
