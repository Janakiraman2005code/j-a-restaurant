import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

export default function Register(){
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const nav = useNavigate();
  const submit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('/api/auth/register', { name, email, password }, { withCredentials: true });
      nav('/');
    } catch (err) { alert('Register failed'); }
  };
  return (
    <div className="max-w-md mx-auto bg-white p-6 rounded shadow">
      <h2 className="text-xl font-semibold mb-4">Create account</h2>
      <form onSubmit={submit}>
        <label className="block mb-2">Name<input className="w-full p-2 border rounded" value={name} onChange={e=>setName(e.target.value)} /></label>
        <label className="block mb-2">Email<input className="w-full p-2 border rounded" value={email} onChange={e=>setEmail(e.target.value)} /></label>
        <label className="block mb-4">Password<input type="password" className="w-full p-2 border rounded" value={password} onChange={e=>setPassword(e.target.value)} /></label>
        <button className="px-4 py-2 bg-indigo-600 text-white rounded">Register</button>
      </form>
    </div>
  );
}
