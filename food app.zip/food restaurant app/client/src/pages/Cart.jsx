import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function Cart(){
  const [cart, setCart] = useState([]);
  useEffect(()=> setCart(JSON.parse(localStorage.getItem('cart') || '[]')), []);
  const checkout = async () => {
    try {
      const items = cart.map(i=>({ menuItemId: i.id, qty: i.qty }));
      const body = { restaurantId: cart[0]?.restaurantId, items };
      const res = await axios.post('/api/orders', body, { withCredentials: true });
      alert('Order placed');
      localStorage.removeItem('cart');
      setCart([]);
    } catch (err) { alert('You must be signed in to place an order'); }
  };
  const total = cart.reduce((s,i)=> s + i.price * i.qty, 0);
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Cart</h1>
      <div className="space-y-3">
        {cart.map((c,i)=> (
          <div key={i} className="p-3 bg-white rounded flex justify-between">
            <div>{c.name} x {c.qty}</div>
            <div>${(c.price * c.qty).toFixed(2)}</div>
          </div>
        ))}
      </div>
      <div className="mt-4 text-right">
        <div className="font-semibold">Total: ${total.toFixed(2)}</div>
        <button onClick={checkout} className="mt-2 px-4 py-2 bg-green-600 text-white rounded">Place order</button>
      </div>
    </div>
  );
}
